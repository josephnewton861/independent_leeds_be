const axios = require("axios");

const deleteComment = () => {
  return axios
    .delete(
      "https://bzi4e9gcci.execute-api.eu-west-api.amazonaws.com/beta/independents/test_user1/comments",
      {
        commentId: "b94dce38eafed7688983eba6ac70a4f0",
      }
    )
    .then((response) => {
      console.log(response);
    })
    .catch((error) => {
      console.log(error);
    });
};

deleteComment();
