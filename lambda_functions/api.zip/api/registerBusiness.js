const axios = require("axios");

const registerBusiness = () => {
  return axios
    .patch(
      "https://bzi4e9gcci.execute-api.eu-west-2.amazonaws.com/beta/independents/test_user4/register_business",
      {
        businessName: "We Feed Leeds",
        postCode: "WF59RW",
        address: "11 Bond Street",
        businessType: "Restaurant",
        logoUrl: "www.logo.com",
        about: "This business serves hot food",
        cuisine: "British",
        vegan: "yes",
        vegetarian: "no",
        halal: "yes",
        glutenFree: "no",
        banner: "www.banner.com",
        menu: "chips, £1.50 yorkshire pudding, £6",
        updates: "Currently doing only regular chips and not cheesy",
        phoneNumber: "07748857372",
        facebook: "www.facebook.com",
        twitter: "www.twitter.com",
        instagram: "www.instagram.com",
      }
    )
    .then((response) => {
      console.log(response);
    })
    .catch((error) => {
      console.log(error);
    });
};

registerBusiness();
