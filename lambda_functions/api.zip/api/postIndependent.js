const axios = require("axios");

const postIndependent = () => {
  return axios.post(
    "https://bzi4e9gcci.execute-api.eu-west-2.amazonaws.com/beta/independents",
    {
      emailAddress: "test5@email.com",
      username: "test_user5",
    }
  );
};

postIndependent();
